# SRM Medicine & Health Sciences — Website

React + TypeScript + Vite frontend for the Medicine & Health Sciences division. White-first palette, Sora display type with Playfair Display italic accents, Inter body text.

## Commands
```bash
npm install
npm run dev      # development server
npm run build    # type-check and production build
npm run preview  # preview the production build
```

## Structure
```
src/
  components/   Navbar, Hero, Schools, Admissions, About, Clinical, Research,
                StudentLife, Rankings, Voices, Footer, PhotoSlot
  data/
    content.ts  All copy, navigation, admissions, statistics, rankings, contact
    images.ts   Central image configuration
  hooks/        useInView (scroll reveals), useCountUp (animated statistics)
  styles/globals.css
public/images/  Photographs (see below)
```

## Replacing images
Drop a file into `public/images/` using the name below, or change the path in `src/data/images.ts`. A missing file shows a flat neutral panel, so the layout keeps working.

| Config key | Filename | Section | Suggested ratio | Size |
|---|---|---|---|---|
| hero[0] | hero-01-medical-education.jpg | Hero slide 1 | 4:5 | 1600 × 2000 |
| hero[1] | hero-02-clinical-training.jpg | Hero slide 2 | 4:5 | 1600 × 2000 |
| hero[2] | hero-03-research-lab.jpg | Hero slide 3 | 4:5 | 1600 × 2000 |
| hero[3] | hero-04-patient-care.jpg | Hero slide 4 | 4:5 | 1600 × 2000 |
| hero[4] | hero-05-simulation.jpg | Hero slide 5 | 4:5 | 1600 × 2000 |
| hero[5] | hero-06-healthcare-team.jpg | Hero slide 6 | 4:5 | 1600 × 2000 |
| schools.medicine | school-medicine.jpg | Schools (large) | 16:10 | 2000 × 1250 |
| schools.dentistry | school-dentistry.jpg | Schools | 4:5 | 1200 × 1500 |
| schools.pharmacy | school-pharmacy.jpg | Schools | 4:5 | 1200 × 1500 |
| schools.physiotherapy | school-physiotherapy.jpg | Schools | 4:5 | 1200 × 1500 |
| schools.occupationalTherapy | school-occupational-therapy.jpg | Schools | 4:5 | 1200 × 1500 |
| schools.nursing | school-nursing.jpg | Schools | 16:10 | 2000 × 1250 |
| schools.publicHealth | school-public-health.jpg | Schools | 16:10 | 2000 × 1250 |
| about | about-campus.jpg | About | 4:5 | 1200 × 1500 |
| clinical | clinical-hospital.jpg | Clinical Excellence | 4:3 | 1800 × 1350 |
| research | research-lab.jpg | Research | 5:4 | 1500 × 1200 |
| studentLife[0–3] | student-life-1.jpg … student-life-4.jpg | Campus Life mosaic | mixed | 1600 × 1200 |

## Content editing
All copy and data are in `src/data/content.ts`. Placeholder links use `#`. Replace them with official URLs. Admission links, deadlines and application status must be confirmed from official sources.

Voices and updates (testimonials, experts, alumni, events, news) are placeholders until real content is supplied.

## Animated background system
Decorative illustrations live in `src/components/bg/`. Each one is a custom SVG with a `BgLayer` wrapper (absolute, behind content, `aria-hidden`).

| Component | Where | Animation |
|---|---|---|
| HeroHeart | Hero | Heartbeat pulse (CSS), travelling ECG line (CSS dash), floating particles, Framer Motion entrance |
| MolecularBackground | About | Slow rotation, node drift (CSS), GSAP ScrollTrigger parallax, Framer Motion fade-in |
| NeuralNetwork | Research | Light pulses along paths (CSS offset-path), blinking nodes. Hidden on small screens |
| BreathingLungs | Clinical Excellence | Gentle expansion (CSS), airflow particles (CSS) |
| AnatomicalDrawing | Schools | Stroke-draw reveal on scroll (GSAP ScrollTrigger) |
| MicroscopicCells | Research | Slow translucent drift (CSS). Hidden on small screens |

Keyframes are in `src/styles/background.css`. Colours come from the `--bg-ink` variable, which switches to sage on dark sections. Reduced motion shows static illustrations, and small screens get fewer particles and fewer layers.

To remove a background, delete its component from the section file.
