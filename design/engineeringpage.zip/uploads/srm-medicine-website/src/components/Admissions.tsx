import { ArrowRight } from 'lucide-react';
import { admissions } from '../data/content';
import { useInView } from '../hooks/useInView';

export default function Admissions() {
  const { ref, inView } = useInView<HTMLDivElement>(0.2);
  return (
    <section id="admissions" className="section section-tint">
      <div className="container">
        <header className="section-head">
          <p className="kicker">Admissions</p>
          <h2 className="display">Begin your journey <em>at SRM.</em></h2>
          <p className="muted lede">Explore admission opportunities across our medical and health sciences programmes.</p>
        </header>
        <div ref={ref} className={`adm-grid ${inView ? 'in' : ''}`}>
          {admissions.map((a, i) => (
            <article key={a.title} className={`adm ${a.dark ? 'is-dark' : ''}`} style={{ transitionDelay: `${i * 90}ms` }}>
              <div className="adm-top">
                <span className="adm-index">{a.index}</span>
                <span className="adm-cat">{a.category}</span>
              </div>
              <h3>{a.title}</h3>
              <p>{a.desc}</p>
              <a href={a.href} className="adm-cta" aria-label={`View ${a.title}`}>Details <ArrowRight size={16} aria-hidden /></a>
            </article>
          ))}
        </div>
        <p className="note">Application links and deadlines are placeholders. Confirm them from official sources before publishing.</p>
      </div>
    </section>
  );
}
