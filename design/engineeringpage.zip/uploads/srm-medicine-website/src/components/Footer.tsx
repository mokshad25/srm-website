import { useState, type FormEvent } from 'react';
import { brand, contact, utilityLinks } from '../data/content';

export default function Footer() {
  const [email, setEmail] = useState('');
  const [status, setStatus] = useState('');

  const subscribe = (e: FormEvent) => {
    e.preventDefault();
    if (!/^\S+@\S+\.\S+$/.test(email)) { setStatus('Please enter a valid email address.'); return; }
    setStatus('Thank you for subscribing.');
    setEmail('');
  };

  return (
    <footer id="contact" className="footer">
      <div className="container footer-top">
        <div>
          <p className="kicker">Contact &amp; Enquiries</p>
          <h2 className="display">Let's <em>connect.</em></h2>
          <p className="footer-brand">{brand.name} | {brand.division}</p>
        </div>
        <form className="newsletter" onSubmit={subscribe} noValidate>
          <label htmlFor="newsletter-email">Subscribe to updates</label>
          <div className="newsletter-row">
            <input id="newsletter-email" type="email" placeholder="you@example.com" value={email} onChange={(e) => setEmail(e.target.value)} />
            <button type="submit" className="btn btn-dark">Subscribe</button>
          </div>
          <p className="form-status" role="status">{status}</p>
        </form>
      </div>

      <div className="container footer-grid">
        <section>
          <h4>Head Office</h4>
          <p>{contact.headOffice}</p>
          <h4>SRM Medical College Hospital &amp; Research Centre</h4>
          <p>{contact.hospital}</p>
        </section>
        <section>
          <h4>Admission Helplines</h4>
          <p>{contact.helplines.join(' · ')}</p>
          <h4>Email</h4>
          <p><a href={`mailto:${contact.email}`}>{contact.email}</a></p>
          <h4>Working Hours</h4>
          <p>{contact.hours}</p>
        </section>
        <section>
          <h4>Institutional Links</h4>
          <ul className="footer-links">
            {utilityLinks.map((l) => <li key={l}><a href="#">{l}</a></li>)}
          </ul>
        </section>
      </div>

      <div className="container footer-bottom">
        <p>© 2026 SRM Medical College Hospital &amp; Research Centre (A part of SRM Group). All Rights Reserved.</p>
      </div>
    </footer>
  );
}
