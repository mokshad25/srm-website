import BreathingLungs from "./bg/BreathingLungs";
import { ArrowRight, BookOpen, FlaskConical, HeartPulse, Stethoscope } from 'lucide-react';
import { clinical } from '../data/content';
import { images } from '../data/images';
import PhotoSlot from './PhotoSlot';
import { useInView } from '../hooks/useInView';

const icons = [BookOpen, Stethoscope, FlaskConical, HeartPulse];

export default function Clinical() {
  const { ref, inView } = useInView<HTMLDivElement>(0.2);
  return (
    <section id="clinical" className="section has-bg section-dark">
      <BreathingLungs tone="dark" />
      <div className="container clinical-grid">
        <div className="clinical-copy">
          <p className="kicker kicker-light">Hospital &amp; Clinical Excellence</p>
          <h2 className="display light">{clinical.title}</h2>
          <p className="lede-lg light-soft">{clinical.body}</p>
          <a href="#" className="btn btn-light">Explore the hospital <ArrowRight size={18} aria-hidden /></a>
        </div>
        <PhotoSlot src={images.clinical} alt="SRM Medical College Hospital" className="clinical-img" />
      </div>

      <div className="container">
        <div ref={ref} className={`journey ${inView ? 'in' : ''}`}>
          <span className="journey-line" aria-hidden />
          {clinical.journey.map((j, i) => {
            const Icon = icons[i];
            return (
              <div key={j.label} className="journey-step" style={{ transitionDelay: `${i * 150}ms` }}>
                <span className="journey-icon"><Icon size={22} aria-hidden /></span>
                <span className="journey-num">0{i + 1}</span>
                <h3>{j.label.toUpperCase()}</h3>
                <p>{j.text}</p>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
