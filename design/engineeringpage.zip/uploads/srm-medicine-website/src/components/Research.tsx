import NeuralNetwork from "./bg/NeuralNetwork";
import MicroscopicCells from "./bg/MicroscopicCells";
import { ArrowUpRight } from 'lucide-react';
import { research } from '../data/content';
import { images } from '../data/images';
import PhotoSlot from './PhotoSlot';
import { useInView } from '../hooks/useInView';
import { useCountUp } from '../hooks/useCountUp';

function Metric({ value, prefix, suffix, label, active }: { value: number; prefix: string; suffix: string; label: string; active: boolean }) {
  const n = useCountUp(value, active);
  return (
    <div className="metric">
      <span className="metric-num">{prefix}{n.toLocaleString('en-IN')}{suffix}</span>
      <span className="metric-label">{label}</span>
    </div>
  );
}

export default function Research() {
  const { ref, inView } = useInView<HTMLDivElement>(0.2);
  return (
    <section id="research" className="section has-bg section-tint">
      <NeuralNetwork />
      <MicroscopicCells />
      <div className="container research-grid">
        <div className="research-copy">
          <p className="kicker">Research &amp; Innovation</p>
          <h2 className="display">Discoveries that <em>shape tomorrow.</em></h2>
          <p className="lede-lg">{research.body}</p>
          <ul className="research-items">
            {research.items.map((it) => (
              <li key={it.title}>
                <a href="#" className="research-link">
                  <span>
                    <strong>{it.title}</strong>
                    <span className="muted">{it.text}</span>
                  </span>
                  <ArrowUpRight size={18} aria-hidden />
                </a>
              </li>
            ))}
          </ul>
        </div>
        <div className="research-media">
          <PhotoSlot src={images.research} alt="Research laboratory" className="research-img" />
          <div className="metrics" ref={ref}>
            {research.stats.map((s) => <Metric key={s.label} {...s} active={inView} />)}
          </div>
        </div>
      </div>
    </section>
  );
}
