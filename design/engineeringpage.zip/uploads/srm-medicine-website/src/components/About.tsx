import MolecularBackground from "./bg/MolecularBackground";
import { about, stats } from '../data/content';
import { images } from '../data/images';
import PhotoSlot from './PhotoSlot';
import { useInView } from '../hooks/useInView';
import { useCountUp } from '../hooks/useCountUp';

function Stat({ value, prefix, suffix, label, active }: { value: number; prefix: string; suffix: string; label: string; active: boolean }) {
  const n = useCountUp(value, active);
  return (
    <div className="stat">
      <span className="stat-num">{prefix}{n.toLocaleString('en-IN')}{suffix}</span>
      <span className="stat-label">{label}</span>
    </div>
  );
}

export default function About() {
  const { ref, inView } = useInView<HTMLElement>(0.25);
  return (
    <section id="about" className="section has-bg" ref={ref}>
      <MolecularBackground />
      <div className="container split-layout">
        <div className="about-media">
          <PhotoSlot src={images.about} alt="SRM campus" className="about-img" />
          <p className="caption">Kattankulathur flagship campus</p>
        </div>
        <div className="about-copy">
          <p className="kicker">About SRM</p>
          <h2 className="display">A legacy of learning. <em>A future of discovery.</em></h2>
          <p className="lede-lg">{about.body}</p>
          <ul className="facts">
            {about.facts.map((f) => <li key={f}>{f}</li>)}
          </ul>
        </div>
      </div>
      <div className="container stats-row">
        {stats.map((s) => <Stat key={s.label} {...s} active={inView} />)}
      </div>
    </section>
  );
}
