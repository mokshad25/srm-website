import { useEffect, useState } from 'react';
import { Menu, X } from 'lucide-react';
import { brand, navItems, utilityLinks } from '../data/content';

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  useEffect(() => {
    document.body.style.overflow = open ? 'hidden' : '';
    return () => { document.body.style.overflow = ''; };
  }, [open]);

  const close = () => setOpen(false);

  return (
    <header className={`nav ${scrolled ? 'is-scrolled' : ''}`}>
      <div className="utility" aria-label="Institutional links">
        <ul className="container utility-list">
          {utilityLinks.map((l) => <li key={l}><a href="#">{l}</a></li>)}
        </ul>
      </div>
      <nav className="nav-main container" aria-label="Main">
        <a href="#top" className="brand" onClick={close}>
          <span className="brand-mark">{brand.name}</span>
          <span className="brand-sub">{brand.division}</span>
        </a>

        <ul className="nav-links">
          {navItems.map((item) => (
            <li key={item.label}><a href={item.href}>{item.label}</a></li>
          ))}
        </ul>

        <div className="nav-actions">
          <a href="#admissions" className="btn btn-dark">Apply Now</a>
          <button className="menu-btn" aria-expanded={open} aria-controls="mobile-menu" aria-label={open ? 'Close menu' : 'Open menu'} onClick={() => setOpen((v) => !v)}>
            {open ? <X size={22} /> : <Menu size={22} />}
          </button>
        </div>
      </nav>

      <div id="mobile-menu" className={`mobile-menu ${open ? 'is-open' : ''}`}>
        <ul>
          {navItems.map((item) => (
            <li key={item.label}><a href={item.href} onClick={close}>{item.label}</a></li>
          ))}
        </ul>
        <a href="#admissions" className="btn btn-dark" onClick={close}>Apply Now</a>
      </div>
    </header>
  );
}
