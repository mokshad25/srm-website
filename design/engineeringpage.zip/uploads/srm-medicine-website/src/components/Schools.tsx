import AnatomicalDrawing from "./bg/AnatomicalDrawing";
import { ArrowUpRight } from 'lucide-react';
import { schools } from '../data/content';
import { images } from '../data/images';
import PhotoSlot from './PhotoSlot';
import { useInView } from '../hooks/useInView';

export default function Schools() {
  const { ref, inView } = useInView<HTMLDivElement>(0.15);
  return (
    <section id="schools" className="section has-bg">
      <AnatomicalDrawing />
      <div className="container">
        <header className="section-head split">
          <div>
            <p className="kicker">Our Schools</p>
            <h2 className="display">Seven disciplines. <em>One vision for health.</em></h2>
          </div>
          <p className="muted lede">Explore a multidisciplinary ecosystem bringing together healthcare education, research and patient care.</p>
        </header>

        <div ref={ref} className={`schools-grid ${inView ? 'in' : ''}`}>
          {schools.map((s, i) => (
            <a key={s.key} href={s.href} className={`school ${s.span}`} style={{ transitionDelay: `${i * 70}ms` }}>
              <PhotoSlot src={images.schools[s.key]} alt={`${s.name} training`} className="school-img" />
              <div className="school-shade" aria-hidden />
              <div className="school-text">
                <span className="school-index">{String(i + 1).padStart(2, '0')}</span>
                <h3>{s.name}</h3>
                <p>{s.desc}</p>
              </div>
              <span className="school-go" aria-hidden><ArrowUpRight size={20} /></span>
            </a>
          ))}
        </div>
      </div>
    </section>
  );
}
