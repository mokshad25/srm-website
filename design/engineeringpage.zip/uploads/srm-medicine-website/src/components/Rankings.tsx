import { rankings } from '../data/content';
import { useInView } from '../hooks/useInView';
import { useCountUp } from '../hooks/useCountUp';

function Rank({ value, active }: { value: number; active: boolean }) {
  return <>{useCountUp(value, active, 1200)}</>;
}

export default function Rankings() {
  const { ref, inView } = useInView<HTMLElement>(0.2);
  return (
    <section id="rankings" className="section section-tint" ref={ref}>
      <div className="container rank-layout">
        <div>
          <p className="kicker">Rankings &amp; Recognition</p>
          <h2 className="display">Excellence <em>recognised.</em></h2>
          <p className="muted note-block">{rankings.note}</p>
        </div>
        <ol className="rank-list">
          {rankings.items.map((r) => (
            <li key={r.label}>
              <span className="rank-label">{r.label}</span>
              <span className="rank-num">#<Rank value={r.rank} active={inView} /></span>
            </li>
          ))}
        </ol>
      </div>
    </section>
  );
}
