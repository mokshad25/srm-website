import { useState } from 'react';

interface Props {
  src: string;
  alt: string;
  className?: string;
  /** Pass true for images that are purely decorative. */
  decorative?: boolean;
}

/** Photo with a flat neutral fallback, so a missing file never breaks the layout. */
export default function PhotoSlot({ src, alt, className = '', decorative = false }: Props) {
  const [failed, setFailed] = useState(false);
  if (failed || !src) {
    return <div className={`photo-fallback ${className}`} role={decorative ? undefined : 'img'} aria-label={decorative ? undefined : alt} aria-hidden={decorative || undefined} />;
  }
  return (
    <img
      className={`photo ${className}`}
      src={src}
      alt={decorative ? '' : alt}
      loading="lazy"
      decoding="async"
      onError={() => setFailed(true)}
    />
  );
}
