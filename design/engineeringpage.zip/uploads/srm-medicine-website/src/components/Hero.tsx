import HeroHeart from "./bg/HeroHeart";
import { useEffect, useState } from 'react';
import { ArrowRight, ChevronLeft, ChevronRight } from 'lucide-react';
import { hero } from '../data/content';
import { images } from '../data/images';
import PhotoSlot from './PhotoSlot';

const INTERVAL = 7000;

export default function Hero() {
  const total = hero.slides.length;
  const [index, setIndex] = useState(0);
  const [paused, setPaused] = useState(false);

  useEffect(() => {
    if (paused || window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;
    const id = window.setInterval(() => setIndex((i) => (i + 1) % total), INTERVAL);
    return () => window.clearInterval(id);
  }, [paused, total]);

  const go = (n: number) => setIndex(((n % total) + total) % total);
  const slide = hero.slides[index];
  const pad = (n: number) => String(n + 1).padStart(2, '0');

  return (
    <section id="top" className="hero has-bg" onMouseEnter={() => setPaused(true)} onMouseLeave={() => setPaused(false)}>
      <HeroHeart />
      <div className="container hero-grid">
        <div className="hero-copy">
          <p className="kicker reveal">Medicine &amp; Health Sciences</p>
          <h1 className="hero-title reveal delay-1" key={index}>
            {slide.lines.map((l) => <span key={l} className="line">{l}</span>)}
            {slide.accent && <em className="accent">{slide.accent}</em>}
          </h1>
          <p className="hero-body reveal delay-2">{hero.body}</p>
          <div className="hero-ctas reveal delay-3">
            <a href={hero.ctaPrimary.href} className="btn btn-dark">{hero.ctaPrimary.label} <ArrowRight size={18} aria-hidden /></a>
            <a href={hero.ctaSecondary.href} className="btn btn-ghost">{hero.ctaSecondary.label}</a>
          </div>

          <div className="slide-controls">
            <span className="slide-count" aria-live="polite">{pad(index)} <span>/ {pad(total - 1)}</span></span>
            <span className="slide-label">{slide.label}</span>
            <div className="slide-arrows">
              <button aria-label="Previous slide" onClick={() => go(index - 1)}><ChevronLeft size={18} /></button>
              <button aria-label="Next slide" onClick={() => go(index + 1)}><ChevronRight size={18} /></button>
            </div>
          </div>
          <div className="progress" role="tablist" aria-label="Choose slide">
            {hero.slides.map((s, i) => (
              <button key={s.label} role="tab" aria-selected={i === index} aria-label={s.label} className={i === index ? 'is-active' : ''} onClick={() => go(i)} />
            ))}
          </div>
        </div>

        <div className="hero-media">
          {images.hero.map((src, i) => (
            <PhotoSlot key={src} src={src} alt={hero.slides[i].label} className={`hero-img ${i === index ? 'is-active' : ''}`} />
          ))}
        </div>
      </div>
    </section>
  );
}
