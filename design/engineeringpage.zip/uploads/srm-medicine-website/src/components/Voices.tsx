import { voices } from '../data/content';

export default function Voices() {
  return (
    <section className="section">
      <div className="container">
        <header className="section-head">
          <p className="kicker">Voices &amp; Updates</p>
          <h2 className="display">{voices.title}</h2>
        </header>
        <div className="voices">
          {voices.items.map((v) => (
            <article key={v.kind} className="voice">
              <span className="voice-kind">{v.kind}</span>
              <p>{v.note}</p>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}
