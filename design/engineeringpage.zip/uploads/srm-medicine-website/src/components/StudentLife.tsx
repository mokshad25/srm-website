import { studentLife } from '../data/content';
import { images } from '../data/images';
import PhotoSlot from './PhotoSlot';

export default function StudentLife() {
  const [a, b, c, d] = images.studentLife;
  return (
    <section id="student-life" className="section">
      <div className="container">
        <header className="section-head split">
          <div>
            <p className="kicker">Campus Life</p>
            <h2 className="display">More than a degree. <em>A community.</em></h2>
          </div>
        </header>
        <div className="life-mosaic">
          <figure className="life-tile tile-a"><PhotoSlot src={a} alt="Students on campus" className="tile-img" />
            <figcaption><span>{studentLife.items[0].kicker}</span>{studentLife.items[0].title}</figcaption></figure>
          <figure className="life-tile tile-b"><PhotoSlot src={b} alt="Campus activity" className="tile-img" />
            <figcaption><span>{studentLife.items[1].kicker}</span>{studentLife.items[1].title}</figcaption></figure>
          <figure className="life-tile tile-c"><PhotoSlot src={c} alt="Student life moments" className="tile-img" />
            <figcaption><span>{studentLife.items[2].kicker}</span>{studentLife.items[2].title}</figcaption></figure>
          <figure className="life-tile tile-d"><PhotoSlot src={d} alt="Students in the community" className="tile-img" /></figure>
        </div>
      </div>
    </section>
  );
}
