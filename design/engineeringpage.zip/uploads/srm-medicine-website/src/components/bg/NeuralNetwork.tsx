import { motion } from 'framer-motion';
import BgLayer from './BgLayer';
import { useMotionPrefs } from '../../hooks/useMotionPrefs';

const LAYERS = [70, 230, 390, 550, 710];
const y = (l: number, i: number) => 80 + i * 130 + (l % 2 === 0 ? 0 : 65);

interface Edge { d: string; idx: number }
const EDGES: Edge[] = [];
for (let l = 0; l < LAYERS.length - 1; l++) {
  for (let i = 0; i < 4; i++) {
    for (const j of [i, (i + 1) % 4]) {
      const x1 = LAYERS[l], y1 = y(l, i), x2 = LAYERS[l + 1], y2 = y(l + 1, j), mx = (x1 + x2) / 2;
      EDGES.push({ d: `M${x1} ${y1} C${mx} ${y1} ${mx} ${y2} ${x2} ${y2}`, idx: EDGES.length });
    }
  }
}

export default function NeuralNetwork() {
  const { reduced } = useMotionPrefs();
  return (
    <BgLayer className="neural">
      <motion.svg
        viewBox="0 0 780 600"
        preserveAspectRatio="xMidYMid slice"
        initial={{ opacity: 0 }}
        whileInView={{ opacity: 1 }}
        viewport={{ once: true }}
        transition={{ duration: 2 }}
      >
        {EDGES.map((e) => <path key={e.idx} d={e.d} className="line" />)}
        {!reduced && EDGES.filter((e) => e.idx % 3 === 0).map((e) => (
          <circle
            key={`p${e.idx}`}
            r={2.4}
            className="pulse"
            style={{
              offsetPath: `path("${e.d}")`,
              animationDuration: `${3 + (e.idx % 4) * 0.8}s`,
              animationDelay: `${-(e.idx * 0.37)}s`,
            }}
          />
        ))}
        {LAYERS.flatMap((x, l) => [0, 1, 2, 3].map((i) => (
          <circle key={`n${l}-${i}`} cx={x} cy={y(l, i)} r={4} className={reduced ? 'node-core' : 'node-blink'} style={{ animationDelay: `${-(l + i) * 0.6}s` }} />
        )))}
      </motion.svg>
    </BgLayer>
  );
}
