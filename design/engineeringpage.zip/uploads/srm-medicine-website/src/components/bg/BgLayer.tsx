import type { ReactNode } from 'react';

interface Props {
  children: ReactNode;
  className?: string;
}

/** Decorative, non-interactive layer. Sits behind content (z-index 0). */
export default function BgLayer({ children, className = '' }: Props) {
  return <div className={`bg-layer ${className}`} aria-hidden="true">{children}</div>;
}
