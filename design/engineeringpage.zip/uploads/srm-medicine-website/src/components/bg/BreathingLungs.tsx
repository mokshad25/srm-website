import BgLayer from './BgLayer';
import { useMotionPrefs } from '../../hooks/useMotionPrefs';

const LOBE = 'M262 150 C232 160 196 196 186 262 C176 330 186 408 226 440 C252 458 276 440 280 402 L282 200 C283 170 276 146 262 150 Z';
const AIRWAYS = 'M300 60 L300 170 M300 170 L272 214 M300 170 L328 214 M272 214 L240 250 M328 214 L360 250';

export default function BreathingLungs({ tone = 'light' }: { tone?: 'light' | 'dark' }) {
  const { reduced } = useMotionPrefs();
  return (
    <BgLayer className={`lungs ${tone === 'dark' ? 'bg-on-dark' : ''}`}>
      <svg className="lungs-svg" viewBox="0 0 600 500" aria-hidden="true">
        <g className={reduced ? undefined : 'lungs-breathe'}>
          <path d={AIRWAYS} className="line" />
          <path d={LOBE} className="line" />
          <path d={LOBE} className="line" transform="translate(600 0) scale(-1 1)" />
        </g>
        {!reduced && [0, 1, 2, 3, 4].map((i) => (
          <circle
            key={i}
            cx={286 + i * 7}
            cy={70 + (i % 2) * 10}
            r={1.8}
            className="airflow"
            style={{ animationDelay: `${i * 0.9}s` }}
          />
        ))}
      </svg>
    </BgLayer>
  );
}
