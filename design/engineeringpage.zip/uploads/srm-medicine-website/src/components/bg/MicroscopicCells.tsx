import { motion } from 'framer-motion';
import BgLayer from './BgLayer';
import { useMotionPrefs } from '../../hooks/useMotionPrefs';

const CELLS = [
  { x: 120, y: 110, r: 72, rot: -12, d: 26, delay: -3 },
  { x: 380, y: 210, r: 48, rot: 20, d: 32, delay: -9 },
  { x: 610, y: 120, r: 62, rot: 6, d: 29, delay: -14 },
  { x: 220, y: 420, r: 56, rot: -28, d: 34, delay: -6 },
  { x: 540, y: 430, r: 84, rot: 14, d: 38, delay: -18 },
  { x: 730, y: 330, r: 36, rot: 0, d: 24, delay: -11 },
];

export default function MicroscopicCells({ tone = 'light' }: { tone?: 'light' | 'dark' }) {
  const { reduced, simple } = useMotionPrefs();
  const cells = simple ? CELLS.slice(0, 3) : CELLS;

  return (
    <BgLayer className={`cells ${tone === 'dark' ? 'bg-on-dark' : ''}`}>
      <motion.svg
        viewBox="0 0 800 600"
        preserveAspectRatio="xMidYMid slice"
        initial={{ opacity: 0 }}
        whileInView={{ opacity: 1 }}
        viewport={{ once: true }}
        transition={{ duration: 2.4 }}
      >
        {cells.map((c, i) => (
          <g
            key={i}
            className={reduced ? undefined : 'cell-drift'}
            style={{ animationDuration: `${c.d}s`, animationDelay: `${c.delay}s` }}
          >
            <ellipse cx={c.x} cy={c.y} rx={c.r} ry={c.r * 0.82} transform={`rotate(${c.rot} ${c.x} ${c.y})`} className="cell-membrane" />
            <circle cx={c.x + c.r * 0.12} cy={c.y - c.r * 0.08} r={c.r * 0.36} className="cell-nucleus" />
            <circle cx={c.x - c.r * 0.45} cy={c.y + c.r * 0.35} r={c.r * 0.07} className="cell-organelle" />
            <circle cx={c.x + c.r * 0.5} cy={c.y + c.r * 0.3} r={c.r * 0.05} className="cell-organelle" />
          </g>
        ))}
      </motion.svg>
    </BgLayer>
  );
}
