import { useEffect, useRef } from 'react';
import BgLayer from './BgLayer';
import { gsap, ScrollTrigger } from '../../lib/gsap';
import { useMotionPrefs } from '../../hooks/useMotionPrefs';

const ribs: string[] = [];
for (let i = 0; i < 5; i++) {
  const y = 212 + i * 28;
  ribs.push(`M200 ${y} C150 ${y - 8} 132 ${y + 26} 146 ${y + 46}`);
  ribs.push(`M200 ${y} C250 ${y - 8} 268 ${y + 26} 254 ${y + 46}`);
}

const PATHS = [
  'M200 40 C240 40 262 70 262 104 C262 130 252 146 240 158 L240 176 L160 176 L160 158 C148 146 138 130 138 104 C138 70 160 40 200 40 Z',
  'M200 180 L200 430',
  'M130 200 L200 186 L270 200',
  'M140 206 L110 330 L96 420',
  'M260 206 L290 330 L304 420',
  'M150 420 C160 400 240 400 250 420 C262 452 236 480 200 480 C164 480 138 452 150 420 Z',
  'M170 470 L160 580 L150 680',
  'M230 470 L240 580 L250 680',
  ...ribs,
];

export default function AnatomicalDrawing() {
  const { reduced } = useMotionPrefs();
  const svgRef = useRef<SVGSVGElement>(null);

  // Draw each stroke along its path when the section scrolls into view.
  useEffect(() => {
    const svg = svgRef.current;
    if (!svg || reduced) return;
    const paths = Array.from(svg.querySelectorAll<SVGPathElement>('path.draw'));
    paths.forEach((p) => {
      const len = p.getTotalLength();
      gsap.set(p, { strokeDasharray: len, strokeDashoffset: len });
    });
    const tween = gsap.to(paths, {
      strokeDashoffset: 0,
      duration: 2.4,
      stagger: 0.12,
      ease: 'power2.inOut',
      scrollTrigger: { trigger: svg, start: 'top 80%', once: true },
    });
    return () => { tween.scrollTrigger?.kill(); tween.kill(); ScrollTrigger.refresh(); };
  }, [reduced]);

  return (
    <BgLayer className="anat">
      <svg ref={svgRef} className="anat-svg" viewBox="0 0 400 700" preserveAspectRatio="xMidYMid meet" aria-hidden="true">
        {PATHS.map((d) => <path key={d} d={d} className="line draw" />)}
      </svg>
    </BgLayer>
  );
}
