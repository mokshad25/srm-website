import { useEffect, useRef } from 'react';
import { motion } from 'framer-motion';
import BgLayer from './BgLayer';
import { gsap, ScrollTrigger } from '../../lib/gsap';
import { useMotionPrefs } from '../../hooks/useMotionPrefs';

const NODES: [number, number][] = [
  [120, 90], [260, 60], [410, 120], [560, 80], [700, 150], [180, 260], [330, 240],
  [480, 290], [640, 270], [110, 420], [300, 400], [470, 450], [650, 430], [740, 360], [240, 520],
];

const dist = (a: [number, number], b: [number, number]) => Math.hypot(a[0] - b[0], a[1] - b[1]);
const EDGES: [number, number][] = [];
NODES.forEach((a, i) => NODES.forEach((b, j) => { if (j > i && dist(a, b) < 210) EDGES.push([i, j]); }));

export default function MolecularBackground() {
  const { reduced, simple } = useMotionPrefs();
  const svgRef = useRef<SVGSVGElement>(null);

  // Slow scroll parallax on the molecule field.
  useEffect(() => {
    const el = svgRef.current;
    if (!el || reduced) return;
    const tween = gsap.to(el, {
      yPercent: -12,
      ease: 'none',
      scrollTrigger: { trigger: el.closest('section'), start: 'top bottom', end: 'bottom top', scrub: true },
    });
    return () => { tween.scrollTrigger?.kill(); tween.kill(); ScrollTrigger.refresh(); };
  }, [reduced]);

  const nodes = simple ? NODES.slice(0, 9) : NODES;

  return (
    <BgLayer className="molecular">
      <motion.svg
        ref={svgRef}
        viewBox="0 0 800 560"
        preserveAspectRatio="xMidYMid slice"
        initial={{ opacity: 0 }}
        whileInView={{ opacity: 1 }}
        viewport={{ once: true }}
        transition={{ duration: 2.2 }}
      >
        <g className={reduced ? undefined : 'mol-rotate'}>
          {EDGES.filter(([i, j]) => i < nodes.length && j < nodes.length).map(([i, j]) => (
            <line key={`${i}-${j}`} x1={NODES[i][0]} y1={NODES[i][1]} x2={NODES[j][0]} y2={NODES[j][1]} className="line mol-edge" />
          ))}
          {nodes.map(([x, y], i) => (
            <g key={i} className={reduced ? undefined : 'mol-node'} style={{ animationDuration: `${16 + (i % 5) * 3}s`, animationDelay: `${-i * 1.4}s` }}>
              <circle cx={x} cy={y} r={i % 3 === 0 ? 6 : 3.5} className="line" />
              <circle cx={x} cy={y} r={1.6} className="node-core" />
            </g>
          ))}
        </g>
      </motion.svg>
    </BgLayer>
  );
}
