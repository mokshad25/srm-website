import { motion } from 'framer-motion';
import BgLayer from './BgLayer';
import { useMotionPrefs } from '../../hooks/useMotionPrefs';

const HEART =
  'M200 362 C120 304 40 242 40 152 C40 98 80 62 130 62 C162 62 186 80 200 104 C214 80 238 62 270 62 C320 62 360 98 360 152 C360 242 280 304 200 362 Z';
const VESSELS = ['M200 104 C200 76 214 46 246 34', 'M172 78 L162 30', 'M228 78 L238 30', 'M200 150 C176 170 166 196 170 228', 'M200 150 C224 170 234 196 230 228'];
const ECG =
  'M0 80 H300 L320 80 L332 52 L344 108 L356 30 L370 124 L382 80 H520 L540 80 L552 52 L564 108 L576 30 L590 124 L602 80 H760 L780 80 L792 52 L804 108 L816 30 L830 124 L842 80 H1000 L1020 80 L1032 52 L1044 108 L1056 30 L1070 124 L1082 80 H1200';

const particles = Array.from({ length: 14 }, (_, i) => ({
  x: 40 + ((i * 53) % 320),
  y: 40 + ((i * 97) % 320),
  r: 1 + (i % 3) * 0.6,
  d: 7 + (i % 5) * 1.6,
  delay: -(i * 1.3),
}));

export default function HeroHeart() {
  const { reduced, simple } = useMotionPrefs();
  const dots = simple ? particles.slice(0, 6) : particles;

  return (
    <BgLayer className="hero-heart">
      <motion.svg
        className="heart-svg"
        viewBox="0 0 400 400"
        initial={{ opacity: 0, scale: 0.96 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 2.4, ease: [0.2, 0.7, 0.2, 1] }}
      >
        <g className={reduced ? undefined : 'heart-pulse'}>
          <path d={HEART} className="line" />
          {VESSELS.map((d) => <path key={d} d={d} className="line" />)}
        </g>
        {dots.map((p, i) => (
          <circle
            key={i}
            cx={p.x}
            cy={p.y}
            r={p.r}
            className={reduced ? 'particle-static' : 'float-dot'}
            style={{ animationDuration: `${p.d}s`, animationDelay: `${p.delay}s` }}
          />
        ))}
      </motion.svg>

      <svg className="ecg-track" viewBox="0 0 1200 160" preserveAspectRatio="none" aria-hidden="true">
        <path
          d={ECG}
          pathLength={1000}
          className={`line ecg ${reduced ? '' : 'ecg-travel'}`}
        />
      </svg>
    </BgLayer>
  );
}
