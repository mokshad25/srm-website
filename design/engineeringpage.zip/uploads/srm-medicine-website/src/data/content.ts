/** All editable copy lives here. Components render this data only. */

export const brand = { name: 'SRM', division: 'Medicine & Health Sciences' };

export const navItems = [
  { label: 'Programmes', href: '#schools' },
  { label: 'Admissions', href: '#admissions' },
  { label: 'Research', href: '#research' },
  { label: 'Clinical Excellence', href: '#clinical' },
  { label: 'Campus Life', href: '#student-life' },
  { label: 'About', href: '#about' },
];

export const utilityLinks = [
  'NMC', 'Associated Hospital', 'Medical Programme Regulations', 'Internal Complaint Committee',
  'UGC', 'Anti-Ragging Cell', 'Blogs', 'COVID-19 Care @ SRM',
  'Pro-Forma of College Information', 'ECHS',
];

export const hero = {
  slides: [
    { label: 'Medical education', lines: ['Where science', 'meets'], accent: 'compassion.' },
    { label: 'Clinical training', lines: ['Learning at', 'the bedside.'], accent: '' },
    { label: 'Research', lines: ['Discovery at', 'the bench.'], accent: '' },
    { label: 'Patient care', lines: ['Care, informed', 'by evidence.'], accent: '' },
    { label: 'Medical simulation', lines: ['Practice before', 'the patient.'], accent: '' },
    { label: 'Healthcare teams', lines: ['Healthcare,', 'built together.'], accent: '' },
  ],
  body: 'A multidisciplinary ecosystem of medical education, clinical excellence, research and healthcare innovation.',
  ctaPrimary: { label: 'Explore Our Schools', href: '#schools' },
  ctaSecondary: { label: 'Admissions 2026–27', href: '#admissions' },
};

export const schools = [
  { key: 'medicine', name: 'Medicine', desc: 'Clinical science and patient care.', href: '/schools/medicine', span: 'span-7 tall' },
  { key: 'dentistry', name: 'Dentistry', desc: 'Oral health and dental sciences.', href: '/schools/dentistry', span: 'span-5' },
  { key: 'pharmacy', name: 'Pharmacy', desc: 'Medicines and pharmaceutical innovation.', href: '/schools/pharmacy', span: 'span-4' },
  { key: 'physiotherapy', name: 'Physiotherapy', desc: 'Movement and rehabilitation.', href: '/schools/physiotherapy', span: 'span-4' },
  { key: 'occupationalTherapy', name: 'Occupational Therapy', desc: 'Independence and everyday living.', href: '/schools/occupational-therapy', span: 'span-4' },
  { key: 'nursing', name: 'Nursing', desc: 'Compassionate and evidence-based care.', href: '/schools/nursing', span: 'span-6' },
  { key: 'publicHealth', name: 'Public Health', desc: 'Healthier communities and population wellbeing.', href: '/schools/public-health', span: 'span-6' },
] as const;

export const admissions = [
  { index: '01', category: 'NEET Admissions', title: 'Application 2026–2027', desc: 'Undergraduate medical admissions.', href: '#', dark: false },
  { index: '02', category: 'NEET Admissions', title: 'Super Specialty (DM/MCh) 2025', desc: 'Super Specialty admissions.', href: '#', dark: false },
  { index: '03', category: 'NEET Admissions', title: 'MD/MS Admissions 2026', desc: 'Postgraduate medical admissions.', href: '#', dark: false },
  { index: '04', category: 'PhD Admissions', title: 'MHS PhD Admissions', desc: 'Doctoral research programmes.', href: '#', dark: true },
];

export const about = {
  title: 'A legacy of learning. A future of discovery.',
  body: 'SRM is one of the largest multidisciplinary higher educational institutions in India, catering to over 45,000 students across 8 campuses in 5 states. Imparting education par excellence since 1985, SRM offers more than 300 programmes in Engineering & Technology, Medicine, Dentistry and Other Health Sciences, Science & Humanities, Management, Law, Agricultural Sciences, and Hotel Management.',
  facts: [
    'Flagship campus in Kattankulathur, about 30 minutes from Chennai',
    'Campus spans more than 250 acres',
    'Students from over 95 countries',
  ],
};

export const stats = [
  { value: 45000, prefix: '', suffix: '+', label: 'Students' },
  { value: 8, prefix: '', suffix: '', label: 'Campuses' },
  { value: 5, prefix: '', suffix: '', label: 'States' },
  { value: 300, prefix: '', suffix: '+', label: 'Programmes' },
  { value: 95, prefix: '', suffix: '+', label: 'Countries' },
  { value: 250, prefix: '', suffix: '+', label: 'Acres' },
];

export const clinical = {
  title: 'Where knowledge meets care.',
  body: 'SRM Medical College Hospital & Research Centre connects academic learning with practical experience, so students train in real clinical settings alongside experienced healthcare professionals.',
  journey: [
    { label: 'Learning', text: 'Foundations in science and clinical reasoning.' },
    { label: 'Practice', text: 'Supervised training in clinical environments.' },
    { label: 'Research', text: 'Questions from the ward carried into the lab.' },
    { label: 'Care', text: 'Patient-centred service for the community.' },
  ],
};

export const research = {
  title: 'Discoveries that shape tomorrow.',
  body: 'Research across the institution is organised through Centres of Excellence and shared through MedXplore, which brings together research stories from across SRM.',
  stats: [
    { value: 25000, prefix: '', suffix: '+', label: 'Publications' },
    { value: 300, prefix: '₹', suffix: '+ Cr', label: 'Research funding' },
    { value: 100, prefix: '', suffix: '+', label: 'Patents' },
  ],
  items: [
    { title: 'Institutional Centres of Excellence', text: 'Focused research centres across the institution.' },
    { title: 'MedXplore: SRM Research Stories', text: 'Research highlights and stories from our community.' },
  ],
};

export const studentLife = {
  title: 'More than a degree. A community.',
  items: [
    { kicker: 'Student Life', title: 'Learn, Leap and Lead.' },
    { kicker: 'Campus Ecosystem', title: 'Integrated Eco-System @ SRM.' },
    { kicker: 'Campus Stories', title: 'Every Photo Has a Story.' },
  ],
};

export const rankings = {
  note: 'These are SRM institutional NIRF 2025 rankings. They are not rankings specific to Medicine & Health Sciences alone.',
  items: [
    { label: 'University', rank: 11 },
    { label: 'Engineering', rank: 14 },
    { label: 'Research', rank: 25 },
    { label: 'Medical', rank: 18 },
    { label: 'Overall', rank: 22 },
    { label: 'Pharmacy', rank: 10 },
    { label: 'Dental', rank: 8 },
  ],
};

export const voices = {
  title: 'Voices and updates.',
  items: [
    { kind: 'Testimonial', note: 'Student testimonial — content to be supplied.' },
    { kind: 'Expert', note: "Let's hear from our experts — content to be supplied." },
    { kind: 'Alumni', note: 'Know your alumni — content to be supplied.' },
    { kind: 'Event', note: 'Upcoming event — details to be supplied.' },
    { kind: 'News', note: 'Latest news and updates — to be supplied.' },
  ],
};

export const contact = {
  headOffice: 'No. 3 Veerasamy Street, Mambalam, Chennai, Tamil Nadu 600033.',
  hospital: 'SRM Nagar, Potheri, Chengalpattu, Tamil Nadu 603203.',
  helplines: ['+91 7026472647', '7418905444', '7418907444', '9791938654'],
  email: 'dean.medical.ktr@srmist.edu.in',
  hours: 'Monday–Friday, 9:00 AM–5:00 PM',
};
