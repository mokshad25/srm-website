/**
 * Central image configuration. Replace any file by dropping it into
 * public/images/ with the same name, or change the path below.
 * Missing files render a flat neutral panel, so the layout never breaks.
 */
export const images = {
  hero: [
    '/images/hero-01-medical-education.jpg',
    '/images/hero-02-clinical-training.jpg',
    '/images/hero-03-research-lab.jpg',
    '/images/hero-04-patient-care.jpg',
    '/images/hero-05-simulation.jpg',
    '/images/hero-06-healthcare-team.jpg',
  ],
  schools: {
    medicine: '/images/school-medicine.jpg',
    dentistry: '/images/school-dentistry.jpg',
    pharmacy: '/images/school-pharmacy.jpg',
    physiotherapy: '/images/school-physiotherapy.jpg',
    occupationalTherapy: '/images/school-occupational-therapy.jpg',
    nursing: '/images/school-nursing.jpg',
    publicHealth: '/images/school-public-health.jpg',
  },
  about: '/images/about-campus.jpg',
  clinical: '/images/clinical-hospital.jpg',
  research: '/images/research-lab.jpg',
  studentLife: [
    '/images/student-life-1.jpg',
    '/images/student-life-2.jpg',
    '/images/student-life-3.jpg',
    '/images/student-life-4.jpg',
  ],
} as const;
