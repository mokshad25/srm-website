import Navbar from './components/Navbar';
import Hero from './components/Hero';
import Schools from './components/Schools';
import Admissions from './components/Admissions';
import About from './components/About';
import Clinical from './components/Clinical';
import Research from './components/Research';
import StudentLife from './components/StudentLife';
import Rankings from './components/Rankings';
import Voices from './components/Voices';
import Footer from './components/Footer';

export default function App() {
  return (
    <>
      <a className="skip-link" href="#main">Skip to content</a>
      <Navbar />
      <main id="main">
        <Hero />
        <Schools />
        <Admissions />
        <About />
        <Clinical />
        <Research />
        <StudentLife />
        <Rankings />
        <Voices />
      </main>
      <Footer />
    </>
  );
}
