import { useEffect, useState } from 'react';
import { useReducedMotion } from 'framer-motion';

/** reduced: user asked for less motion. simple: small screen, so decorative layers are lightened. */
export function useMotionPrefs() {
  const reduced = useReducedMotion() ?? false;
  const [simple, setSimple] = useState(false);
  useEffect(() => {
    const mq = window.matchMedia('(max-width: 760px)');
    const update = () => setSimple(mq.matches);
    update();
    mq.addEventListener('change', update);
    return () => mq.removeEventListener('change', update);
  }, []);
  return { reduced, simple };
}
